# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
import time
from datetime import datetime

class SearchProblem:
	"""
	This class outlines the structure of a search problem, but doesn't implement
	any of the methods (in object-oriented terminology: an abstract class).

	You do not need to change anything in this class, ever.
	"""

	def getStartState(self):
		"""
		Returns the start state for the search problem.
		"""
		util.raiseNotDefined()

	def isGoalState(self, state):
		"""
		  state: Search state

		Returns True if and only if the state is a valid goal state.
		"""
		util.raiseNotDefined()

	def getSuccessors(self, state):
		"""
		  state: Search state

		For a given state, this should return a list of triples, (successor,
		action, stepCost), where 'successor' is a successor to the current
		state, 'action' is the action required to get there, and 'stepCost' is
		the incremental cost of expanding to that successor.
		"""
		util.raiseNotDefined()

	def getCostOfActions(self, actions):
		"""
		 actions: A list of actions to take

		This method returns the total cost of a particular sequence of actions.
		The sequence must be composed of legal moves.
		"""
		util.raiseNotDefined()


def tinyMazeSearch(problem):
	"""
	Returns a sequence of moves that solves tinyMaze.  For any other maze, the
	sequence of moves will be incorrect, so only use this for tinyMaze.
	"""
	from game import Directions
	s = Directions.SOUTH
	w = Directions.WEST
	return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
	
	frontiers = util.Stack()
	exploredSet = set()
	paths=[]
	curPath=[]
	movements=[]
	"""
	The implement of DFS is quite similar to BFS
	The similar comments are simply omitted
	Differences are commented
	"""
	start = round(time.time()*1000)
	start_ = datetime.utcnow()
	if problem.isGoalState(problem.getStartState()):
		return 'Stop'
		
	#DFS uses a LIFO STACK to store frontiers
	frontiers.push((problem.getStartState(),'Start',0))
	paths.append([problem.getStartState()])
	
	while not frontiers.isEmpty():
		curFrontier= frontiers.pop()
		
		if problem.isGoalState(curFrontier[0]):
			break
		
		#Notice!
		#IN BFS, curPath is at the beginning of list "paths" becuase "frontiers" is FIFO
		#IN DFS, curPath is at the end of list "paths" becuase "frontiers" is LIFO
		curPath=paths.pop()
		if curFrontier[0] not in exploredSet:
			exploredSet.add(curFrontier[0])
			successors=[]
			successors = problem.getSuccessors(curFrontier[0])
			for successor in successors:
				if successor[0] not in exploredSet:
					path=[]
					path= curPath[:]
					path.append(successor)
					paths.append(path)
					frontiers.push(successor)
	
	#Notice!
	#IN BFS, result is at the beginning of list "paths" becuase "frontiers" is FIFO
	#IN DFS, result is at the end of list "paths" becuase "frontiers" is LIFO
	for movement in paths[-1][1:]:
		movements.append(movement[1])
	end = round(time.time()*1000)
	end_ = datetime.utcnow()
	c = (end_ - start_)	
	print "time",c.seconds  
	print "time",c.microseconds 
	print "time",c
	return movements
	
	
def breadthFirstSearch(problem):
	"""Search the shallowest nodes in the search tree first."""
	frontiers = util.Queue()
	exploredSet = set()
	paths=[]
	curPath=[]
	movements=[]
	
	start = round(time.time()*1000)
	start_ = datetime.utcnow()
	
	#if the start state is the goal state
	#stop immediately
	if problem.isGoalState(problem.getStartState()):
		return 'Stop'
	
	#if the start state is not the goal state
	#start searching
	frontiers.push((problem.getStartState(),'Start',0))
	paths.append([problem.getStartState()])
	
	while not frontiers.isEmpty():
		#curFronitier is the top of FIFO QUEUE frontiers
		#So curFrontier is shallowest unexplored node
		curFrontier= frontiers.pop()
		
		#Goal state test
		if problem.isGoalState(curFrontier[0]):
			break
		
		#curPath is the corresponding path to curFrontier
		curPath=paths.pop(0)
		successors=[]
		
		#ensure curFrontier is unexplored
		if curFrontier[0] not in exploredSet:
			exploredSet.add(curFrontier[0])
			successors = problem.getSuccessors(curFrontier[0])
			for successor in successors:
				if successor[0] not in exploredSet:
					#path=curPath->successor
					path=[]
					path= curPath[:]
					path.append(successor)
					paths.append(path)
					#push successsor into FIFO QUEUE
					frontiers.push(successor)
			
	
	#extract "action" part from paths
	#so that the pacman can follow this instruction
	for movement in paths[0][1:]:
		movements.append(movement[1])
		
	end = round(time.time()*1000)
	end_ = datetime.utcnow()
	c = (end_ - start_)
	print "time",c.seconds  
	print "time",c.microseconds 
	print "time",c
	return movements

def uniformCostSearch(problem):
	"""Search the node of least total cost first."""
	#frontiers has different foramt in UCS
	#paths are included in frontiers to avoid chaos
	frontiers = util.PriorityQueue()
	exploredSet = set()
	movements=[]
	solutions=[]
	
	start = round(time.time()*1000)
	start_ = datetime.utcnow()
	if problem.isGoalState(problem.getStartState()):
		return 'Stop'
	
	#tuples in "frontiers" are like below:
	#[(x,y), [node1,node2,...], pathcost]
	frontiers.push((problem.getStartState(),[]),0)
	
	while not frontiers.isEmpty():
		curFrontier= frontiers.pop()
		movements=curFrontier[1]
		#searching process continues even the goal state is achieved
		#extra test to ensure the path is optimal
		if problem.isGoalState(curFrontier[0]):
			solutions.append((movements, problem.getCostOfActions(movements)))
		if curFrontier[0] not in exploredSet:
			exploredSet.add(curFrontier[0])
			successors=[]
			successors = problem.getSuccessors(curFrontier[0])
			for successor in successors:
				child=successor[0]
				action=successor[1]
				path=movements[:]
				path.append(action)
				frontiers.push((child,path),problem.getCostOfActions(path))
	
	#test whethter the path is optimal
	movements=solutions[0][0]
	mincost=solutions[0][1]
	for solution in solutions:
		if solution[1]<mincost:
			movements=solution[0]
	
	end = round(time.time()*1000)
	end_ = datetime.utcnow()
	c = (end_ - start_)
	print "time",c.seconds  
	print "time",c.microseconds 
	print "time",c
	return movements
	
	


def nullHeuristic(state, problem=None):
	"""
	A heuristic function estimates the cost from the current state to the nearest
	goal in the provided SearchProblem.  This heuristic is trivial.
	"""
	return 0

def aStarSearch(problem, heuristic=nullHeuristic):
	"""Search the node that has the lowest combined cost and heuristic first."""
	"*** YOUR CODE HERE ***"
	util.raiseNotDefined()


# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
