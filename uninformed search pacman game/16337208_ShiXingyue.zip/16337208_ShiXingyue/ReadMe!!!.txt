- BFS, DFS, UCS I implemented are in "search.py"

- To test, use these command:
	��Find a solution using BFS (using given MazeData):
	python pacman.py -l mediumMaze -p SearchAgent -a fn=bfs
	��Find a solution using DFS (using given MazeData):
	python pacman.py -l mediumMaze -p SearchAgent -a fn=dfs
	��Find a solution using UCS (using given MazeData):
	python pacman.py -l mediumMaze -p SearchAgent -a fn=ucs
	��Find a solution using UCS (using DottedMaze where cost functions are inconstant):
	python pacman.py -l mediumDottedMaze -p StayEastSearchAgent -a fn=ucs
	��Find a solution using UCS (using ScaryMaze where cost functions are inconstant):
	python pacman.py -l mediumScaryMaze -p StayWestSearchAgent -a fn=ucs

-Notes
	You may need to install python-tk first if running on Linux OS
	Some codes originally in this project run more smoothly using Python2.

- Declaimer
	This project is based on UC Berkeley Pacman Project materials. I extend it by implementing search algorithms
