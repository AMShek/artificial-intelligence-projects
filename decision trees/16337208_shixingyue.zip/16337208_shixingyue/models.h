#pragma once
#include <iostream>
#include <vector>
using namespace std;

struct Node {
	int Data[1700][7];
	int Label[1700];
	int Attr[7];
	int datasize;//the num of samples 
	int attrsize;//the num of attr available to choose from 
	int attr_chosen;//attr to split on
	int final_label;//label decided by majority voting 
	int attr_num;
	vector <Node*> children; 
	bool prune_or_not;
};
double Empirical_entropy(Node *p);
double Conditional_entropy(int attr_index, Node *p);
double gini(int attr_index, Node* p);
double SplitInfo(int attr_index, Node* p);
int ID3(Node *p);
int C4_5(Node* p);
int CART(Node* p);


double Empirical_entropy(Node *p){
	double HD;
	double acceptable = 0, unacceptable = 0;
	for (int i = 0; i<p->datasize; i++)
	{
		if (p->Label[i] == 1) acceptable++;
		else unacceptable++;
	}
	HD = -1 * (acceptable / p->datasize)*log(acceptable / p->datasize) - ((unacceptable / p->datasize)*log(unacceptable / p->datasize));
	return HD;
}
double Conditional_entropy(int attr_index, Node *p){
	int maxnum = 0, minnum = 1000;
	for (int i = 0; i<p->datasize; i++) {
		if (p->Data[i][attr_index]<minnum) minnum = p->Data[i][attr_index];
		if (p->Data[i][attr_index]>maxnum) maxnum = p->Data[i][attr_index];
	}
	double HDA = 0;
	for (int i = minnum; i <= maxnum; i++) {		
		double acceptable = 0, unacceptable = 0, cnt = 0;
		for (int j = 0; j<p->datasize; j++) { 		
			if (p->Data[j][attr_index] == i) {		
				cnt++; 
				if (p->Label[j] == 1) acceptable++;
				else unacceptable++;
			}
		}
		double A = 0, B = 0, C = 0;
		if (cnt != 0) { 		
			A = (cnt / p->datasize)*-1;
			if (acceptable != 0) B = acceptable / cnt * log(acceptable / cnt);
			if (unacceptable != 0) C = unacceptable / cnt * log(unacceptable / cnt);
			HDA += A * (B + C);
		}
	}
	return HDA;
}
double gini(int attr_index, Node* p){
	int maxnum = 0, minnum = 1000;
	for (int i = 0; i<p->datasize; i++) {
		if (p->Data[i][attr_index]<minnum) minnum = p->Data[i][attr_index];
		if (p->Data[i][attr_index]>maxnum) maxnum = p->Data[i][attr_index];
	}
	double gini = 0;
	for (int i = minnum; i <= maxnum; i++) {			
		double acceptable = 0, unacceptable = 0, cnt = 0;
		for (int j = 0; j<p->datasize; j++) { 		
			if (p->Data[j][attr_index] == i) {
				cnt++;
				if (p->Label[j] == 1) acceptable++;
				else unacceptable++;
			}
		}
		double A = 0, B = 0, C = 0;
		if (cnt != 0) {	 
			A = (cnt / p->datasize);
			B = (acceptable / cnt)*(acceptable / cnt);
			C = (unacceptable / cnt)*(unacceptable / cnt);
			gini += A * (1 - B - C);
		}
	}
	return gini;
}
double SplitInfo(int attr_index, Node* p)//��������λ��Ϊattr_index���������� 
{
	int maxnum = 0, minnum = 1000;
	for (int i = 0; i<p->datasize; i++)//�ȱ����ҳ���ǰ����������ֵ����Сֵ�����ֵ 
	{
		if (p->Data[i][attr_index]<minnum) minnum = p->Data[i][attr_index];
		if (p->Data[i][attr_index]>maxnum) maxnum = p->Data[i][attr_index];
	}
	double sp_info = 0;//��ǰ��������  
	for (int i = minnum; i <= maxnum; i++)//�������п��ܵ�ȡֵ 
	{
		double cnt = 0;//ȡֵΪi������������  
		for (int j = 0; j<p->datasize; j++)//������������ 
		{
			if (p->Data[j][attr_index] == i)//�ҳ�ȡֵΪi���������� 
				cnt++;//��¼ȡֵΪi������������ 
		}
		if (cnt != 0)	sp_info += -1 * (cnt / p->datasize)*log(cnt / p->datasize);
	}
	return sp_info;
}
int ID3(Node *p){
	//previous entropy
	double HD = Empirical_entropy(p);
	//entropy after introducing this attribute
	double HDA[7];
	double gain[7], maxGain = -100;
	for (int i = 0; i < p->attrsize; i++) {
		HDA[i] = Conditional_entropy(i, p); 
	}	
	int max_index = 0; 
	for (int i = 0; i<p->attrsize; i++){
		gain[i] = HD - HDA[i];
		if (gain[i]>maxGain) { 
			maxGain = gain[i];	max_index = i; 
		}
	}
	return p->Attr[max_index]; 
}
int C4_5(Node* p){
	double HD = Empirical_entropy(p);
	double gainRatio[7];
	double maxGainRatio = 0;
	for (int i = 0; i<p->attrsize; i++) {
		gainRatio[i] = (HD - Conditional_entropy(i, p)) / SplitInfo(i, p);
	}
	int max_index = 0;
	for (int i = 0; i<p->attrsize; i++){
		if (gainRatio[i]>maxGainRatio){
			maxGainRatio = gainRatio[i];	
			max_index = i;
		}
	}
	return p->Attr[max_index]; 
}
int CART(Node* p)
{
	double Gini[7];
	for (int i = 0; i < p->attrsize; i++) {
		Gini[i] = gini(i, p);
	}
	double minnum = 1000;  
	int min_index = 0;
	for (int i = 0; i<p->attrsize; i++){
		if (Gini[i]<minnum){
			minnum = Gini[i]; 
			min_index = i;
		}
	}
	return p->Attr[min_index];
}
