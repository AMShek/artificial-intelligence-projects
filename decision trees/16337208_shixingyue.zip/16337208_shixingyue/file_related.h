#pragma once
#include <iostream>
#include <algorithm>
#include <string>
#include <cstdio>
#include <set>
#include <vector>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cmath>
#include <fstream>
using namespace std;
void output_test_result();
void Readtest();
void ReadTrain();

int Length;//the num of attr
int traincnt = 0;//size of train set
int train[1700][7];//train set
int label[1700];//labels of train set
int valicnt = 0;//size of validation set
int vali[1000][7];//validation set
int valilabel[1000];//labels of validation set
int vali_label_result[1700];//predicted labels of validation set
int cnt_of_leave = 0;//the num of leaves
int cnt_of_arriving_leaf = 0;//the num of samples reaching leaves
int cnt_of_not_arriving_leaf = 0; 
int cnt_of_pruned_leaves = 0;
int test[500][7];//test set 
int testcnt = 0;//size of test set
int test_label_result[500];//predited labels of test set
int test_cnt_of_arriving_leaf = 0;//the num of samples reaching leaves
int test_cnt_of_not_arriving_leaf = 0;
int testacceptable;
int testunacceptable;

void output_test_result(){
	ofstream fout;
	fout.open("C://Users//mibyb//source//repos//decision_trees//Debug//output.csv");
	for (int i = 0; i<testcnt; i++)	{
		fout << test_label_result[i] << endl;
		if (test_label_result[i] == 1) testacceptable++;
		else if (test_label_result[i] == 0) testunacceptable++;
	}
	fout.close();
}
void Readtest(){
	ifstream fin("C://Users//mibyb//source//repos//decision_trees//Debug//Car_test.csv");
	string line;
	vector<string> fields;
	testcnt = 0;
	while (getline(fin, line)){
		fields.clear();
		istringstream sin(line);
		string field;
		while (getline(sin, field, ','))
			fields.push_back(field);
		for (int i = 0; i<fields.size() - 1; i++)	{
			double temnum;
			if (i == 0 || i == 1) {
				if (fields[i] == "vhigh") temnum = 3;
				else if (fields[i] == "high") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			else if (i == 2) {
				if (fields[i] == "5more") temnum = 3;
				else if (fields[i] == "4") temnum = 2;
				else if (fields[i] == "3") temnum = 1;
				else temnum = 0;
			}
			else if (i == 3) {
				if (fields[i] == "more") temnum = 2;
				else if (fields[i] == "4") temnum = 1;
				else temnum = 0;
			}
			else if (i == 4) {
				if (fields[i] == "big") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			else {
				if (fields[i] == "high") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			test[testcnt][i] = temnum;
		}
		testcnt++;
	}
	fin.close();
}
void ReadTrain(){
	ifstream fin("C://Users//mibyb//source//repos//decision_trees//Debug//Car_train.csv");
	string line;
	vector<string> fields;
	int cnt = 1;
	traincnt = 0;
	valicnt = 0;
	while (getline(fin, line)){
		fields.clear();
		istringstream sin(line);
		string field;
		while (getline(sin, field, ','))
			fields.push_back(field);

		for (int i = 0; i<fields.size(); i++){
			double temnum;
			if (i==0 || i==1){
				if (fields[i] == "vhigh") temnum = 3;
				else if (fields[i] == "high") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			else if (i==2){
				if (fields[i] == "5more") temnum = 3;
				else if (fields[i] == "4") temnum = 2;
				else if (fields[i] == "3") temnum = 1;
				else temnum = 0;
			}
			else if (i == 3) {
				if (fields[i] == "more") temnum = 2;
				else if (fields[i] == "4") temnum = 1;
				else temnum = 0;
			}
			else if (i == 4) {
				if (fields[i] == "big") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			else if (i==5){
				if (fields[i] == "high") temnum = 2;
				else if (fields[i] == "med") temnum = 1;
				else temnum = 0;
			}
			else {
				temnum = fields[i] == "1" ? 1 : 0;
			}

			int valid_ratio = 5;//one nth of train set used as validation set
			//label
			if (i == fields.size() - 1){
				//cout << "this is a label, temnum=" << temnum << endl;
				if (cnt%valid_ratio == 0) {
					valilabel[valicnt] = temnum; valicnt++;
				}
				else {
					label[traincnt] = temnum; traincnt++;
				}
			}
			//attributes
			else{
				//cout << "this is an attribute, temnum=" << temnum << endl;
				if (cnt%valid_ratio == 0)
					vali[valicnt][i] = temnum;
				else
					train[traincnt][i] = temnum;
			}
		}
		Length = fields.size();
		cnt++;
	}
	Length--;
	fin.close();
	cout << "traincnt=" << traincnt << "  valicnt=" << valicnt << endl;
}
