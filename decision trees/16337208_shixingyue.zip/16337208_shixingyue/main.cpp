#include<iomanip>
#include <Windows.h>
#include "build_tree.h"
using namespace std;

double accuracy = 0;
void traverse_tree(int index, Node *p, string set);
void prune(Node* p);

void traverse_tree(int index, Node *p, string set)
{
	if (p->children.size() == 0 || p->prune_or_not == 1)
	{
		if (set == "vali")
		{
			vali_label_result[index] = p->final_label;
			cnt_of_arriving_leaf++;
		}
		else if (set == "test")
		{
			test_label_result[index] = p->final_label;
			test_cnt_of_arriving_leaf++;
		}
		return;
	}
	bool flag = 0;
	for (int i = 0; i<p->children.size(); i++)
	{
		int tem;
		if (set == "vali") tem = vali[index][p->attr_chosen];
		else if (set == "test") tem = test[index][p->attr_chosen];
		if (p->children[i]->attr_num == tem)
		{
			if (set == "vali") traverse_tree(index, p->children[i], "vali");
			else if (set == "test") traverse_tree(index, p->children[i], "test");
			flag = 1;
		}
	}
	if (flag == 0){
		int acceptable = 0, unacceptable = 0;
		for (int i = 0; i<p->datasize; i++)
		{
			if (p->Label[i] == 1) acceptable++;
			else unacceptable++;
		}
		if (set == "vali")
		{
			cnt_of_not_arriving_leaf++;
			if (acceptable >= unacceptable) vali_label_result[index] = 1;
			else vali_label_result[index] = -1;
		}
		else if (set == "test")
		{
			test_cnt_of_not_arriving_leaf++;
			if (acceptable >= unacceptable) test_label_result[index] = 1;
			else test_label_result[index] = -1;
		}
	}
}
//post-prune
void prune(Node* p){
	//return when meet with boundary
	if (p->children.size() == 0) 
		return;
	//post traverse
	for (int i = 0; i<p->children.size(); i++){
		//prune recursively
		prune(p->children[i]);
		p->prune_or_not = 1;
		decide_final_label(p);
		for (int i = 0; i<valicnt; i++) traverse_tree(i, root, "vali");
		double right = 0;
		for (int i = 0; i<valicnt; i++){
			if (vali_label_result[i] == valilabel[i]) right++;
		}
		double temac = right / valicnt;
		//if this branch is unnecessary (accuracy doesn't increase), prune branch
		if (temac >= accuracy){
			cnt_of_pruned_leaves++;
			p->children.clear();
			accuracy = temac;
		}
		else
			p->prune_or_not = 0;//choose not to prune
	}
}


int main()
{
	int model;
	initial(); 
	cout << "Choose decision tree models from below:" << endl;
	cout << "0:\tID3" << endl;
	cout << "1:\tC4.5" << endl;
	cout << "2:\tCART" << endl;
	cin >> model;
	recursive(root,model);
	cout << "cnt_of_leave" << cnt_of_leave << endl;
	for (int i = 0; i<valicnt; i++)
		traverse_tree(i, root, "vali");//note�� error here
	cout << "cnt_of_arriving_leaf=" << cnt_of_arriving_leaf << endl;
	cout << "cnt_of_not_arriving_leaf=" << cnt_of_not_arriving_leaf << endl;
	int right = 0;
	for (int i = 0; i < valicnt; i++) {
		if (vali_label_result[i] == valilabel[i]) {
			//cout << "prediction=" << vali_label_result[i] << endl;
			//cout << "real value=" << valilabel[i] << endl;
			right++;
		}

	}
	cout << "valicnt=" << valicnt << endl;//test
	cout << "right=" << right << endl;
	accuracy = (double)right/(double)valicnt;
	cout << "accuracy="<<setprecision(10)<< accuracy *100<<"%"<< endl; 

	prune(root);//��֦	
	cout << "cnt_of_pruned_leaves:" << cnt_of_pruned_leaves << endl;
	cout << "After pruning:accuracy=" << setprecision(10) << accuracy * 100 << "%" << endl;

	Readtest();
	cout << "testcnt=" << testcnt << endl;
	for (int i = 0; i<testcnt; i++)
		traverse_tree(i, root, "test");
	cout << "test_cnt_of_arriving_leaf=" << test_cnt_of_arriving_leaf << endl;
	cout << "test_cnt_of_not_arriving_leaf=" << test_cnt_of_not_arriving_leaf << endl;
	output_test_result();
	cout << "testacceptable=" << testacceptable << endl << "testunacceptable=" << testunacceptable << endl;
	
	system("pause");
	return 0;
}