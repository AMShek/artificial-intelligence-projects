#pragma once
#include "models.h"
#include "file_related.h"
using namespace std;

Node *root = new Node;

void initial();
int choose_attr(Node *p, int select_model);
void decide_final_label(Node* p);
bool meet_with_bound(Node* p);
void recursive(Node *p, int select_model);
//initialize root node
void initial(){
	//read train set, some of train set is used as validation set
	ReadTrain();
	root->datasize = traincnt;
	root->attrsize = Length;
	//not prune at first
	root->prune_or_not = 0;
	//place all train data into root node
	for (int i = 0; i<traincnt; i++){
		for (int j = 0; j < Length; j++){
			root->Data[i][j] = train[i][j];
		}
		root->Label[i] = label[i];
	}
	//all attributes are available to choose for root node
	for (int i = 0; i < Length; i++) {
		root->Attr[i] = i;
	}
	cout << "finish initializing!" << endl;//test
	return;
}
//choose attribute to split on
int choose_attr(Node *p, int select_model){
	int attr;//attributes chosen
	if (select_model==0) attr=ID3(p);
	if (select_model == 1) attr=C4_5(p);
	if (select_model == 2) attr = CART(p);
	return attr;
}
void decide_final_label(Node* p)//decide label of a leaf using majority voting
{
	int  acceptable = 0, unacceptable = 0;
	//evoting
	for (int i = 0; i<p->datasize; i++){
		if (p->Label[i] == 1) acceptable++;
		else unacceptable++;
	}
	if (acceptable >= unacceptable) p->final_label = 1;
	else p->final_label = 0;
}
bool meet_with_bound(Node* p){
	//boundary 1: all labels in train set are identical 
	bool bound_1 = true;
	int firstone = p->Label[0]; 
	for (int i = 0; i<p->datasize; i++) {
		if (p->Label[i] != p->Label[0]) {
			bound_1 = false; 
			break;
		}
	}
	//boundary 2: attrsize=0 or all samples have identical value on all attributes
	//former situation can be regared as a special instance of the later one
	bool bound_2 = true;
	for (int j = 0; j<p->attrsize; j++) {
		int maxnum = 0, minnum = 1000;
		for (int i = 0; i<p->datasize; i++) {
			if (p->Data[i][j]<minnum) 
				minnum = p->Data[i][j];
			if (p->Data[i][j]>maxnum)
				maxnum = p->Data[i][j];
		}
		if (maxnum != minnum) {  		
			bound_2 = false; 
			break;
		}
	}
	//boundary 3: datasize=0
	bool bound_3 = true;
	if (p->datasize != 0) {
		bound_3 = false;
	}
	//meet with bound when at least one kind of boundary is meet
	return (bound_1 || bound_1 || bound_3);
}
void recursive(Node *p, int select_model){
	//meet with boundary, generatew a leaf 
	if (meet_with_bound(p)){
		cnt_of_leave++; 
		decide_final_label(p);
		return;
	}
	//not leaf, continue spliting
	//choose 1 model from 3

	p->attr_chosen = choose_attr(p,select_model);

	//test ouput: see the process of buiding decison tree
	//cout << "split attribute chosen: " << p->attr_chosen << endl;//test

	int index_chosen;
	for (int i = 0; i<p->attrsize; i++)if (p->Attr[i] == p->attr_chosen){
		index_chosen = i; break;
	}
	int maxnum = 0, minnum = 1000;
	for (int i = 0; i<p->datasize; i++){
		if (p->Data[i][index_chosen]<minnum) 
			minnum = p->Data[i][index_chosen];
		if (p->Data[i][index_chosen]>maxnum) 
			maxnum = p->Data[i][index_chosen];
	}
	for (int i = minnum; i <= maxnum; i++){
		Node *tem = new Node;
		//a son to split from current node
		tem->datasize = 0;	
		tem->attrsize = 0;	
		tem->attr_num = i;
		//not prune at first
		tem->prune_or_not = 0;
		//1 less attribute than father node available to choose
		//tem->attrsize = p->attrsize - 1;
		int counter = 0;
		for (int j = 0; j<p->attrsize; j++)if (j != index_chosen){
			tem->Attr[counter] = p->Attr[j];
			counter++;
		}
		tem->attrsize = counter;

		int sample_counter = 0;
		for (int j = 0; j<p->datasize; j++){
			if (p->Data[j][index_chosen] == i){
				tem->Label[sample_counter] = p->Label[j];
				int attr_counter = 0;
				for (int k = 0; k<p->attrsize; k++){
					if (k != index_chosen){
						tem->Data[sample_counter][attr_counter] = p->Data[j][k];
						attr_counter++;
					}
				}
				sample_counter++;
			}
		}
		tem->datasize = sample_counter;
		if (sample_counter != 0)
			p->children.push_back(tem);
		else
			free(tem);
	}
	for (int i = 0; i<p->children.size(); i++)
		recursive(p->children[i],select_model);
}