This project consists of 4 header files and 1 cpp file.
Their objectives are listed below.
Functions implemented in each file are listed at the beginning of the file.

1.file_related.h
	-read train set and seperate a part from it to make validation set
	-read test set
	-output predicted labels to a csv file

2.models.h
	-define data struture "Node" used in decision trees
	-calculate empirical, conditional entropy
	-calculate gini
	-choose split attrubite using ID3
	-choose split attrubite using C4.5
	-choose split attrubite using CART

3.build_tree.h
	-initialize, namely generate root node with train set
	-choose model to dicide split attribute
	-decide label of a node using majority voting
	-decide where spliting meets boundary
	-build tree recursively

4.main.cpp
	-call functions from header files to build tree
	-traverse decision trees to get label for validation and test set
	-prune
	-I/O